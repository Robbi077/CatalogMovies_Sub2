package com.example.catalogmoviessub2.TabLayout;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.catalogmoviessub2.BuildConfig;
import com.example.catalogmoviessub2.R;
import com.example.catalogmoviessub2.ui.MyAsyncTask;

import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 */
public class NowPlaying extends Fragment {
    View view;


    public NowPlaying() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_now_playing, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.RcNow_Playing);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        String endpoint = BuildConfig.Base_Url+"movie/now_playing?api_key=" +
                BuildConfig.Api_Key + "&language="+ Locale.getDefault().toString()
                .replaceAll("_", "_");
        new MyAsyncTask(view.getContext(), recyclerView, endpoint).execute();
        return view;
    }

}
