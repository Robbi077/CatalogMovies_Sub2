package com.example.catalogmoviessub2.TabLayout;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.catalogmoviessub2.BuildConfig;
import com.example.catalogmoviessub2.R;
import com.example.catalogmoviessub2.ui.MyAsyncTask;

import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 */
public class SearchFragmnt extends Fragment {
    View view;
    private EditText editText;
    private Button btn_cari;

    public SearchFragmnt() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_search, container, false);
        final RecyclerView recyclerView = view.findViewById(R.id.Rc_Search);
        editText = view.findViewById(R.id.txt_Search);
        btn_cari = view.findViewById(R.id.btn_cari_fragment);
        btn_cari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v.getId() == R.id.btn_cari_fragment) {
                    String edt_cari = editText.getText().toString();
                    if (TextUtils.isEmpty(edt_cari)) {
                        Toast.makeText(getContext(), R.string.Judul_Movies, Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getContext(), edt_cari, Toast.LENGTH_LONG).show();
                        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
                        String Endpoin = BuildConfig.Base_Url + "search/movie?api_key=" +
                                BuildConfig.Api_Key + "&language=" + Locale.getDefault().toString()
                                .replaceAll("_", "_") + "&query=" + edt_cari;
                        new MyAsyncTask(getContext(),recyclerView,Endpoin).execute();
                    }
                }
            }
        });

        return view;
    }

}
