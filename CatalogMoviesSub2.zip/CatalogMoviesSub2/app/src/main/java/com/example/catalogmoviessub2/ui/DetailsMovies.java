package com.example.catalogmoviessub2.ui;

import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.catalogmoviessub2.MoviesItem;
import com.example.catalogmoviessub2.R;

public class DetailsMovies extends AppCompatActivity {
    static final String Extras_Movies = "Extras_Movies";

    private ImageView imageView, imPoster;
    private TextView txtName, txtDesc, txtRealese;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_movies);
        MoviesItem items = getIntent().getParcelableExtra("senddata2");
        Log.d("senddata2", items + "");
        getSupportActionBar().setTitle(items.getTitle());
        imageView = findViewById(R.id.img_backdrop);
        imPoster = findViewById(R.id.imgPoster);
        txtName = findViewById(R.id.txt_name_detail);
        txtName.setText(items.getTitle());
        txtRealese = findViewById(R.id.txt_realeas);
        txtRealese.setText(items.getRealease());
        txtDesc = findViewById(R.id.txt_overview_detail);
        txtDesc.setText(items.getOverview());
        Uri url_image = Uri.parse("https://image.tmdb.org/t/p/w185" + items.getImages());
        Uri url_image2 = Uri.parse("https://image.tmdb.org/t/p/w185" + items.getPoster());
        Glide.with(this)
                .load(url_image)
                .into(imageView);
        Glide.with(this)
                .load(url_image2)
                .into(imPoster);
    }
}
