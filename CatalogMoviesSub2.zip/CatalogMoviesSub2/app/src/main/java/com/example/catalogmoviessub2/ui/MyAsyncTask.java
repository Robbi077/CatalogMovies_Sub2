package com.example.catalogmoviessub2.ui;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.catalogmoviessub2.MoviesItem;
import com.example.catalogmoviessub2.adapter.MoviesAdapter;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MyAsyncTask extends AsyncTask<Void, Void, ArrayList<MoviesItem>> {
    private ArrayList<MoviesItem> mData;
    private Context context;
    private RecyclerView recyclerView;
    private MoviesAdapter adapter;
    private String mDaftarMovies;

    public MyAsyncTask(Context context, RecyclerView recyclerView, String endpoint) {
        this.context = context;
        this.recyclerView = recyclerView;
        this.mDaftarMovies = endpoint;

    }

    @Override
    protected ArrayList<MoviesItem> doInBackground(Void... voids) {
        return this.Tmpat_Api();
    }

    private ArrayList<MoviesItem> Tmpat_Api() {
        final ArrayList<MoviesItem> list = new ArrayList<>();
        SyncHttpClient client = new SyncHttpClient();
        Log.d("Tmpat_Api: ", mDaftarMovies);
        client.get(mDaftarMovies, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String result = new String(responseBody);
                Log.d("Tmpat_Api2: ", result);

                try{
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray jsonArray = jsonObject.getJSONArray("results");
                    for (int i=0; i<jsonArray.length(); i++){
                        JSONObject weather = jsonArray.getJSONObject(i);
                        MoviesItem data = new MoviesItem(weather);
                        list.add(data);
                    }

                }catch (JSONException e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

            }
        });
        return list;
    }
    @Override
    protected void onPostExecute(final ArrayList<MoviesItem> moviesItems) {
        super.onPostExecute(moviesItems);
        Log.d("Tmpat_Api23: ", String.valueOf(moviesItems));
        adapter = new MoviesAdapter(context,moviesItems);
        recyclerView.setAdapter(adapter);
    }
}
